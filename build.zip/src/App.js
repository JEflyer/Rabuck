import logo from './logo.svg';
import './App.css';
import BlockNative from "./blocknative.js";


function App() {
  return (
    <div className="App">
      <BlockNative />
    </div>
  );
}

export default App;
